﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using jsonreturntodatagrid;
using System.Windows.Controls;
using System.Windows.Data;
using Newtonsoft.Json;
using System.Windows.Input;
using OfficeOpenXml;
using System.Linq;
using System.IO;

using Excel = Microsoft.Office.Interop.Excel;
using System.Text;
namespace jsonreturntodatagrid
{
    public partial class MainWindow : Window
    {
        public class SampleData
        {
            public int AppID { get; set; }
            public string AssetName { get; set; }
            public string DNSName { get; set; }
            public string Desc { get; set; }
            public string Role { get; set; }
            public string Location { get; set; }
            public string IP { get; set; }
            public string Tier { get; set; }
            public string Title { get; set; }
        }
        private  string clientId ;
        private  string stsEndpoint;
        private  string apiEndpoint;
        private  string resource;
        private string redirectUri;
        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
        private ICollectionView dataView;
        
        public MainWindow()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
           //dataView = CollectionViewSource.GetDefaultView(originalData);
            DataGrid.ItemsSource = originalData;


            // Add sample data for testing

            originalData.Add(new SampleData { AppID = 123456, AssetName = "ServerA", DNSName = "ServerA.mydomain.com", Desc = "Windows 2019", Role = "Server-FE", Location = "", IP = "192.168.1.15", Tier = "", Title = "Scrapped" });
            originalData.Add(new SampleData { AppID = 78910, AssetName = "Serverb", DNSName = "Serverb.mydomain.com", Desc = "Windows 2020", Role = "", Location = "Pak", IP = "192.168.1.25", Tier = "Two", Title = "" });
            originalData.Add(new SampleData { AppID = 123456, AssetName = "ServerA", DNSName = "ServerA.mydomain.com", Desc = "Windows 2019", Role = "Server-FE", Location = "", IP = "192.168.1.15", Tier = "", Title = "Scrapped" });
            originalData.Add(new SampleData { AppID = 123456, AssetName = "ServerA", DNSName = "ServerA.mydomain.com", Desc = "Windows 2019", Role = "Server-FE", Location = "", IP = "192.168.1.15", Tier = "", Title = "Scrapped" });
            originalData.Add(new SampleData { AppID = 123456, AssetName = "ServerA", DNSName = "ServerA.mydomain.com", Desc = "Windows 2019", Role = "Server-FE", Location = "", IP = "192.168.1.15", Tier = "", Title = "Scrapped" });


        }

        private async void RetrieveData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Loading data...(This may take a while to fetch the data so please be patient and wait)", "Loading", MessageBoxButton.OK, MessageBoxImage.Information);
                Mouse.OverrideCursor = Cursors.Wait;
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
                Mouse.OverrideCursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
            DataGrid.ItemsSource = null;
        }

        private async Task PerformOAuthFlow()
        {
            await ShowAuthorizationDialog();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }
        private Dictionary<string, string> ParseQueryString(string uri)
        {
            var query = new Uri(uri).Query;
            var queryParams = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(query))
            {
                var pairs = query.TrimStart('?').Split('&');
                foreach (var pair in pairs)
                {
                    var keyValue = pair.Split('=');
                    if (keyValue.Length == 2)
                    {
                        queryParams[keyValue[0]] = Uri.UnescapeDataString(keyValue[1]);
                    }
                }
            }

            return queryParams;
        }

        private async Task ShowAuthorizationDialog()
        {
            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";
            var responseUri = await WebViewDialog.Show(authorizationUri);
            var queryParams = ParseQueryString(responseUri);
            authorizationCode = queryParams["code"];
        }

        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri),
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {

            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = JsonConvert.DeserializeObject<dynamic[]>(jsonData);
            DataGrid.ItemsSource = data;

            originalData.Clear();
            foreach (var item in DataGrid.ItemsSource)
            {
                originalData.Add(item);
            }
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }
        //private void ExportToExcel(string filePath)
        //{
        //    ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
        //    // Create a new Excel package
        //    using (ExcelPackage excelPackage = new ExcelPackage())
        //    {
        //        // Add a new worksheet to the Excel package
        //        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Data");

        //        // Get the data from the DataGrid
        //        var data = (IEnumerable<dynamic>)DataGrid.ItemsSource;

        //        // Write the column headers to the first row of the worksheet
        //        int columnCount = 1;
        //        foreach (var property in data.First().GetType().GetProperties())
        //        {
        //            worksheet.Cells[1, columnCount].Value = property.Name;
        //            columnCount++;
        //        }

        //        // Write the data to the worksheet
        //        int rowCount = 2;
        //        foreach (var item in data)
        //        {
        //            columnCount = 1;
        //            foreach (var property in item.GetType().GetProperties())
        //            {
        //                worksheet.Cells[rowCount, columnCount].Value = property.GetValue(item);
        //                columnCount++;
        //            }
        //            rowCount++;
        //        }

        //        // Save the Excel package to the specified file path
        //        File.WriteAllBytes(filePath, excelPackage.GetAsByteArray());
        //    }

        //    MessageBox.Show("Data exported to Excel successfully.", "Export to Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        //}


        private void ExportToCSV()
        {
            try
            {
                if (DataGrid.Items.Count > 0)
                {
                    Microsoft.Win32.SaveFileDialog sfd = new Microsoft.Win32.SaveFileDialog();
                    sfd.Filter = "CSV (*.csv)|*.csv";
                    sfd.FileName = "";
                    bool fileError = false;
                    if (sfd.ShowDialog() == true)
                    {
                        if (File.Exists(sfd.FileName))
                        {
                            try
                            {
                                File.Delete(sfd.FileName);
                            }
                            catch (IOException ex)
                            {
                                fileError = true;
                                MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                            }
                        }
                        if (!fileError)
                        {
                            try
                            {
                                int columnCount = DataGrid.Columns.Count;
                                string columnNames = "";
                                string[] outputCsv = new string[DataGrid.Items.Count + 1];
                                for (int i = 0; i < columnCount; i++)
                                {
                                    columnNames += DataGrid.Columns[i].Header.ToString() + ",";
                                }
                                outputCsv[0] += columnNames;

                                for (int i = 1; i <= DataGrid.Items.Count; i++)
                                {
                                    var row = DataGrid.Items[i - 1] as SampleData; // Assuming SampleData is the type of your data items
                                    if (row != null)
                                    {
                                        for (int j = 0; j < columnCount; j++)
                                        {
                                            outputCsv[i] += row.GetType().GetProperty(DataGrid.Columns[j].SortMemberPath).GetValue(row, null).ToString() + ",";
                                        }
                                    }
                                }

                                File.WriteAllLines(sfd.FileName, outputCsv, Encoding.UTF8);
                                MessageBox.Show("Data Exported Successfully !!!", "Info");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No Record To Export !!!", "Info");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        // Helper method to release COM objects

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {

            ExportToCSV();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if (radioButton != null && radioButton.IsChecked == true)
            {
                if (radioButton.Name == "ProdRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["ProdClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["ProdStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["ProdApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["ProdResource"];
                    redirectUri = ConfigurationManager.AppSettings["ProdRedirectUri"];
                }
                else if (radioButton.Name == "DevRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["DevClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["DevStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["DevApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["DevResource"];
                    redirectUri = ConfigurationManager.AppSettings["DevRedirectUri"];
                }
            }
        }

        private void SearchData(string searchText)
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                DataGrid.ItemsSource = originalData;
                return;
            }

            var filteredData = originalData.Where(item =>
                item.AppID.ToString().Contains(searchText) ||
                item.AssetName.ToLower().Contains(searchText) ||
                item.DNSName.ToLower().Contains(searchText) ||
                item.Desc.ToLower().Contains(searchText) ||
                item.Role.ToLower().Contains(searchText) ||
                item.Location.ToLower().Contains(searchText) ||
                item.IP.ToLower().Contains(searchText) ||
                item.Tier.ToLower().Contains(searchText) ||
                item.Title.ToLower().Contains(searchText)).ToList();

            DataGrid.ItemsSource = filteredData;
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            SearchData(SearchTextBox.Text);
        }

    }
}