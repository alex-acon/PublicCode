﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using jsonreturntodatagrid;
using System.Windows.Controls;
using System.Windows.Data;
using Newtonsoft.Json;
using System.Windows.Input;
using OfficeOpenXml;
using System.Linq;
using System.IO;

using Excel = Microsoft.Office.Interop.Excel;
using System.Text;
namespace jsonreturntodatagrid
{
    public partial class MainWindow : Window
    {
       
        private  string clientId ;
        private  string stsEndpoint;
        private  string apiEndpoint;
        private  string resource;
        private string redirectUri;
        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
        private ICollectionView dataView;
        
        public MainWindow()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
           //dataView = CollectionViewSource.GetDefaultView(originalData);
            DataGrid.ItemsSource = originalData;


        }

        private async void RetrieveData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Loading data...(This may take a while to fetch the data so please be patient and wait)", "Loading", MessageBoxButton.OK, MessageBoxImage.Information);
                Mouse.OverrideCursor = Cursors.Wait;
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
                Mouse.OverrideCursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
            DataGrid.ItemsSource = null;
        }

        private async Task PerformOAuthFlow()
        {
            await ShowAuthorizationDialog();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }
        private Dictionary<string, string> ParseQueryString(string uri)
        {
            var query = new Uri(uri).Query;
            var queryParams = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(query))
            {
                var pairs = query.TrimStart('?').Split('&');
                foreach (var pair in pairs)
                {
                    var keyValue = pair.Split('=');
                    if (keyValue.Length == 2)
                    {
                        queryParams[keyValue[0]] = Uri.UnescapeDataString(keyValue[1]);
                    }
                }
            }

            return queryParams;
        }

        private async Task ShowAuthorizationDialog()
        {
            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";
            var responseUri = await WebViewDialog.Show(authorizationUri);
            var queryParams = ParseQueryString(responseUri);
            authorizationCode = queryParams["code"];
        }

        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri),
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {

            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = JsonConvert.DeserializeObject<dynamic[]>(jsonData);
            DataGrid.ItemsSource = data;

            
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }
        //private void ExportToExcel(string filePath)
        //{
        //    ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
        //    // Create a new Excel package
        //    using (ExcelPackage excelPackage = new ExcelPackage())
        //    {
        //        // Add a new worksheet to the Excel package
        //        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Data");

        //        // Get the data from the DataGrid
        //        var data = (IEnumerable<dynamic>)DataGrid.ItemsSource;

        //        // Write the column headers to the first row of the worksheet
        //        int columnCount = 1;
        //        foreach (var property in data.First().GetType().GetProperties())
        //        {
        //            worksheet.Cells[1, columnCount].Value = property.Name;
        //            columnCount++;
        //        }

        //        // Write the data to the worksheet
        //        int rowCount = 2;
        //        foreach (var item in data)
        //        {
        //            columnCount = 1;
        //            foreach (var property in item.GetType().GetProperties())
        //            {
        //                worksheet.Cells[rowCount, columnCount].Value = property.GetValue(item);
        //                columnCount++;
        //            }
        //            rowCount++;
        //        }

        //        // Save the Excel package to the specified file path
        //        File.WriteAllBytes(filePath, excelPackage.GetAsByteArray());
        //    }

        //    MessageBox.Show("Data exported to Excel successfully.", "Export to Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        //}


        private void ExportToCSV()
        {
            try
            {
                if (DataGrid.Items.Count > 0)
                {
                    Microsoft.Win32.SaveFileDialog sfd = new Microsoft.Win32.SaveFileDialog();
                    sfd.Filter = "CSV (*.csv)|*.csv";
                    sfd.FileName = "";
                    bool fileError = false;
                    if (sfd.ShowDialog() == true)
                    {
                        if (File.Exists(sfd.FileName))
                        {
                            try
                            {
                                File.Delete(sfd.FileName);
                            }
                            catch (IOException ex)
                            {
                                fileError = true;
                                MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                            }
                        }
                        if (!fileError)
                        {
                            try
                            {
                                int columnCount = DataGrid.Columns.Count;
                                string columnNames = "";
                                string[] outputCsv = new string[DataGrid.Items.Count + 1];
                                for (int i = 0; i < columnCount; i++)
                                {
                                    columnNames += DataGrid.Columns[i].Header.ToString() + ",";
                                }
                                outputCsv[0] += columnNames;

                                for (int i = 1; i <= DataGrid.Items.Count; i++)
                                {
                                    var row = DataGrid.Items[i - 1] as SampleData; // Assuming SampleData is the type of your data items
                                    if (row != null)
                                    {
                                        for (int j = 0; j < columnCount; j++)
                                        {
                                            outputCsv[i] += row.GetType().GetProperty(DataGrid.Columns[j].SortMemberPath).GetValue(row, null).ToString() + ",";
                                        }
                                    }
                                }

                                File.WriteAllLines(sfd.FileName, outputCsv, Encoding.UTF8);
                                MessageBox.Show("Data Exported Successfully !!!", "Info");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No Record To Export !!!", "Info");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        // Helper method to release COM objects

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {

            ExportToCSV();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if (radioButton != null && radioButton.IsChecked == true)
            {
                if (radioButton.Name == "ProdRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["ProdClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["ProdStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["ProdApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["ProdResource"];
                    redirectUri = ConfigurationManager.AppSettings["ProdRedirectUri"];
                }
                else if (radioButton.Name == "DevRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["DevClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["DevStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["DevApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["DevResource"];
                    redirectUri = ConfigurationManager.AppSettings["DevRedirectUri"];
                }
            }
        }

        private void SearchDataGrid(string searchText)
        {
            if (!string.IsNullOrEmpty(searchText))
            {
                List<SampleData> filteredData = new List<SampleData>();

                foreach (SampleData item in DataGrid.Items)
                {
                    if (item.verumIdentifier.ToString().Contains(searchText) ||
                        item.assetName.ToLower().Contains(searchText) ||
                        item.primaryDNSName.ToLower().Contains(searchText) ||
                        item.model.ToLower().Contains(searchText) ||
                        item.managedServiceName.ToLower().Contains(searchText) ||
                        item.adfsarray.ToLower().Contains(searchText) ||
                        item.adfsenv.ToLower().Contains(searchText) ||
                        item.adfsrole.ToLower().Contains(searchText) ||
                        item.site.ToLower().Contains(searchText) || 
                        item.primaryIP.ToLower().Contains(searchText) ||
                        item.nwTiersList.ToLower().Contains(searchText) ||
                        item.statusT.ToLower().Contains(searchText) ||
                        item.subStatus.ToLower().Contains(searchText))
                            
                    {
                        filteredData.Add(item);
                    }
                }

                DataGrid.ItemsSource = filteredData;
            }
            else
            {
                // If the search text is empty, restore the original data source to the DataGrid
                DataGrid.ItemsSource = originalData;
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            SearchDataGrid(SearchTextBox.Text);
        }

    }
    public class SampleData
    {

        public string verumIdentifier { get; set; }
        public string assetName { get; set; }
        public string primaryDNSName { get; set; }
        public string model { get; set; }
        public string managedServiceName { get; set; }
        public string adfsarray { get; set; }
        public string adfsenv { get; set; }
        public string adfsrole { get; set; }
        public string site { get; set; }
        public string primaryIP { get; set; }
        public string nwTiersList { get; set; }
        public string statusT { get; set; }
        public string subStatus { get; set; }
    }
}