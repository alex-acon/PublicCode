﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace jsonreturntodatagrid
{
    public partial class WebViewDialog : Window
    {
        public string ResponseUri { get; private set; }

        private WebViewDialog(string url)
        {
            InitializeComponent();
            webBrowser.Navigate(new Uri(url));
        }

        private void WebBrowser_Navigated(object sender, NavigationEventArgs e)
        {
            ResponseUri = e.Uri.ToString();
            DialogResult = true;
        }

        private void WebBrowser_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            // Optionally, you can handle navigation events here
        }

        public static async Task<string> Show(string url)
        {
            var tcs = new TaskCompletionSource<string>();

            var webViewDialog = new WebViewDialog(url);
            webViewDialog.Closed += (sender, args) => tcs.TrySetResult(webViewDialog.ResponseUri);

            if (webViewDialog.ShowDialog() == true)
            {
                return await tcs.Task;
            }
            else
            {
                throw new Exception("Authorization canceled by the user.");
            }
        }
    }
}
