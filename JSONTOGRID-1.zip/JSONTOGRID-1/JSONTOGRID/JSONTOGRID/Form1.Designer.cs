﻿namespace JSONTOGRID
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.AppIDTextBox = new System.Windows.Forms.TextBox();
            this.ObjectTypeTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ObjectNameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.RetrieveDataButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExportButton = new System.Windows.Forms.Button();
            this.ProdRadioButton = new System.Windows.Forms.RadioButton();
            this.DevRadioButton = new System.Windows.Forms.RadioButton();
            this.SearchTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "AppID:";
            // 
            // AppIDTextBox
            // 
            this.AppIDTextBox.Location = new System.Drawing.Point(14, 25);
            this.AppIDTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.AppIDTextBox.Name = "AppIDTextBox";
            this.AppIDTextBox.Size = new System.Drawing.Size(132, 21);
            this.AppIDTextBox.TabIndex = 1;
            // 
            // ObjectTypeTextBox
            // 
            this.ObjectTypeTextBox.Location = new System.Drawing.Point(156, 25);
            this.ObjectTypeTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.ObjectTypeTextBox.Name = "ObjectTypeTextBox";
            this.ObjectTypeTextBox.Size = new System.Drawing.Size(132, 21);
            this.ObjectTypeTextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(158, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "ObjectType:";
            // 
            // ObjectNameTextBox
            // 
            this.ObjectNameTextBox.Location = new System.Drawing.Point(298, 25);
            this.ObjectNameTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.ObjectNameTextBox.Name = "ObjectNameTextBox";
            this.ObjectNameTextBox.Size = new System.Drawing.Size(169, 21);
            this.ObjectNameTextBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(295, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "ObjectName (optional):";
            // 
            // RetrieveDataButton
            // 
            this.RetrieveDataButton.Location = new System.Drawing.Point(614, 5);
            this.RetrieveDataButton.Name = "RetrieveDataButton";
            this.RetrieveDataButton.Size = new System.Drawing.Size(117, 50);
            this.RetrieveDataButton.TabIndex = 6;
            this.RetrieveDataButton.Text = "Retrieve Data";
            this.RetrieveDataButton.UseVisualStyleBackColor = true;
            this.RetrieveDataButton.Click += new System.EventHandler(this.RetrieveDataButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(737, 5);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(117, 50);
            this.ClearButton.TabIndex = 7;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExportButton
            // 
            this.ExportButton.Location = new System.Drawing.Point(857, 5);
            this.ExportButton.Name = "ExportButton";
            this.ExportButton.Size = new System.Drawing.Size(117, 50);
            this.ExportButton.TabIndex = 8;
            this.ExportButton.Text = "Export to Excel";
            this.ExportButton.UseVisualStyleBackColor = true;
            this.ExportButton.Click += new System.EventHandler(this.ExportButton_Click);
            // 
            // ProdRadioButton
            // 
            this.ProdRadioButton.AutoSize = true;
            this.ProdRadioButton.Location = new System.Drawing.Point(485, 26);
            this.ProdRadioButton.Name = "ProdRadioButton";
            this.ProdRadioButton.Size = new System.Drawing.Size(55, 19);
            this.ProdRadioButton.TabIndex = 9;
            this.ProdRadioButton.TabStop = true;
            this.ProdRadioButton.Text = "Prod";
            this.ProdRadioButton.UseVisualStyleBackColor = true;
            this.ProdRadioButton.CheckedChanged += new System.EventHandler(this.ProdRadioButton_CheckedChanged);
            // 
            // DevRadioButton
            // 
            this.DevRadioButton.AutoSize = true;
            this.DevRadioButton.Location = new System.Drawing.Point(559, 26);
            this.DevRadioButton.Name = "DevRadioButton";
            this.DevRadioButton.Size = new System.Drawing.Size(49, 19);
            this.DevRadioButton.TabIndex = 10;
            this.DevRadioButton.TabStop = true;
            this.DevRadioButton.Text = "Dev";
            this.DevRadioButton.UseVisualStyleBackColor = true;
            this.DevRadioButton.CheckedChanged += new System.EventHandler(this.DevRadioButton_CheckedChanged);
            // 
            // SearchTextBox
            // 
            this.SearchTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchTextBox.Location = new System.Drawing.Point(737, 61);
            this.SearchTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.SearchTextBox.Name = "SearchTextBox";
            this.SearchTextBox.Size = new System.Drawing.Size(237, 21);
            this.SearchTextBox.TabIndex = 11;
            this.SearchTextBox.TextChanged += new System.EventHandler(this.SearchTextBox_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(960, 537);
            this.dataGridView1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 637);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.SearchTextBox);
            this.Controls.Add(this.DevRadioButton);
            this.Controls.Add(this.ProdRadioButton);
            this.Controls.Add(this.ExportButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.RetrieveDataButton);
            this.Controls.Add(this.ObjectNameTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ObjectTypeTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AppIDTextBox);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Data Retrieval App";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AppIDTextBox;
        private System.Windows.Forms.TextBox ObjectTypeTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ObjectNameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button RetrieveDataButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExportButton;
        private System.Windows.Forms.RadioButton ProdRadioButton;
        private System.Windows.Forms.RadioButton DevRadioButton;
        private System.Windows.Forms.TextBox SearchTextBox;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

