﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using System.Net.Http;

using Newtonsoft.Json;
using System.Reflection;
using System.IO;
namespace JSONTOGRID
{
    public partial class Form1 : Form
    {
        List<SampleData> sampleData = new List<SampleData>();
        private string clientId;
        private string stsEndpoint;
        private string apiEndpoint;
        private string resource;
        private string redirectUri;
        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
       // private ICollectionView dataView;

        public Form1()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
            //dataView = CollectionViewSource.GetDefaultView(originalData);
            dataGridView1.DataSource = originalData;
           
        }
       

        private async Task PerformOAuthFlow()
        {
            await ShowAuthorizationDialog();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }
        private Dictionary<string, string> ParseQueryString(string uri)
        {
            var query = new Uri(uri).Query;
            var queryParams = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(query))
            {
                var pairs = query.TrimStart('?').Split('&');
                foreach (var pair in pairs)
                {
                    var keyValue = pair.Split('=');
                    if (keyValue.Length == 2)
                    {
                        queryParams[keyValue[0]] = Uri.UnescapeDataString(keyValue[1]);
                    }
                }
            }

            return queryParams;
        }

        private async Task ShowAuthorizationDialog()
        {
            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";
            var responseUri = await WebViewDialog.Show(authorizationUri);
            var queryParams = ParseQueryString(responseUri);
            authorizationCode = queryParams["code"];
        }

        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri),
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {

            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = (JsonConvert.DeserializeObject<dynamic[]>(jsonData)).ToString();
            dataGridView1.DataSource = data;
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ProdRadioButton.Checked = true; 
        }

        private  void ClearButton_Click(object sender, EventArgs e)
        {

            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
           dataGridView1.DataSource = null;
          
            
        }
        private void save()
        {
          
            sampleData.Clear();

            // Iterate through each row in the DataGridView
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Create a SampleData object and populate its properties from the DataGridView row
                SampleData dataItem = new SampleData
                {
                    verumIdentifier = row.Cells["verumIdentifier"].Value?.ToString(),
                    assetName = row.Cells["assetName"].Value?.ToString(),
                    primaryDNSName = row.Cells["primaryDNSName"].Value?.ToString(),
                    model = row.Cells["model"].Value?.ToString(),
                    managedServiceName = row.Cells["managedServiceName"].Value?.ToString(),
                    adfsarray = row.Cells["adfsarray"].Value?.ToString(),
                    adfsenv = row.Cells["adfsenv"].Value?.ToString(),
                    adfsrole = row.Cells["adfsrole"].Value?.ToString(),
                    site = row.Cells["site"].Value?.ToString(),
                    primaryIP = row.Cells["primaryIP"].Value?.ToString(),
                    nwTiersList = row.Cells["nwTiersList"].Value?.ToString(),
                    statusT = row.Cells["statusT"].Value?.ToString(),
                    subStatus = row.Cells["subStatus"].Value?.ToString()
                };

                // Add the SampleData object to the sampleData list
                sampleData.Add(dataItem);
                
            }
            dataGridView1.DataSource = sampleData;
        }
        private async void RetrieveDataButton_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Loading data...(This may take a while to fetch the data so please be patient and wait)", "Loading", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Cursor.Current = Cursors.WaitCursor;
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
                save();
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void ProdRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            clientId = ConfigurationManager.AppSettings["ProdClientId"];
            stsEndpoint = ConfigurationManager.AppSettings["ProdStsEndpoint"];
            apiEndpoint = ConfigurationManager.AppSettings["ProdApiEndpoint"];
            resource = ConfigurationManager.AppSettings["ProdResource"];
            redirectUri = ConfigurationManager.AppSettings["ProdRedirectUri"];
        }

        private void DevRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            clientId = ConfigurationManager.AppSettings["DevClientId"];
            stsEndpoint = ConfigurationManager.AppSettings["DevStsEndpoint"];
            apiEndpoint = ConfigurationManager.AppSettings["DevApiEndpoint"];
            resource = ConfigurationManager.AppSettings["DevResource"];
            redirectUri = ConfigurationManager.AppSettings["DevRedirectUri"];
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.Filter = "CSV (*.csv)|*.csv";
                    sfd.FileName = "";
                    bool fileError = false;
                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        if (File.Exists(sfd.FileName))
                        {
                            try
                            {
                                File.Delete(sfd.FileName);
                            }
                            catch (IOException ex)
                            {
                                fileError = true;
                                MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                            }
                        }
                        if (!fileError)
                        {
                            try
                            {
                                int columnCount = dataGridView1.Columns.Count;
                                string columnNames = "";
                                string[] outputCsv = new string[dataGridView1.Rows.Count + 1];
                                for (int i = 0; i < columnCount; i++)
                                {
                                    columnNames += dataGridView1.Columns[i].HeaderText.ToString() + ",";
                                }
                                outputCsv[0] += columnNames;

                                for (int i = 1; (i - 1) < dataGridView1.Rows.Count; i++)
                                {
                                    for (int j = 0; j < columnCount; j++)
                                    {
                                        outputCsv[i] += dataGridView1.Rows[i - 1].Cells[j].Value.ToString() + ",";
                                    }
                                }

                                File.WriteAllLines(sfd.FileName, outputCsv, Encoding.UTF8);
                                MessageBox.Show("Data Exported Successfully !!!", "Info");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error :" + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No Record To Export !!!", "Info");
                }
            }
            catch { }

        }
      private void search(string taxt)
        {
            try
            {

                if (SearchTextBox.Text != "")
                {
                    IEnumerable<SampleData> sh = sampleData;
                    var items = sh.Where(s => s.verumIdentifier.ToLower().Contains(taxt) || s.subStatus.ToLower().Contains(taxt) || s.statusT.ToLower().Contains(taxt) || s.nwTiersList.ToLower().Contains(taxt) || s.primaryIP.ToLower().Contains(taxt) || s.site.ToLower().Contains(taxt) || s.adfsrole.ToLower().Contains(taxt) || s.adfsarray.ToLower().Contains(taxt) || s.model.ToLower().Contains(taxt) || s.managedServiceName.ToLower().Contains(taxt) || s.adfsenv.ToLower().Contains(taxt) || s.primaryDNSName.ToLower().Contains(taxt) || s.assetName.ToLower().Contains(taxt));
                    dataGridView1.DataSource = items.ToList();
                }
                else
                {
                    dataGridView1.DataSource = sampleData.ToList();
                }
               
            }
            catch { }
        }
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            search(SearchTextBox.Text);
        }
    }
   
    public class SampleData
    {

        public string verumIdentifier { get; set; }
        public string assetName { get; set; }
        public string primaryDNSName { get; set; }
        public string model { get; set; }
        public string managedServiceName { get; set; }
        public string adfsarray { get; set; }
        public string adfsenv { get; set; }
        public string adfsrole { get; set; }
        public string site { get; set; }
        public string primaryIP { get; set; }
        public string nwTiersList { get; set; }
        public string statusT { get; set; }
        public string subStatus { get; set; }
    }
}
