﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JSONTOGRID
{
    public partial class WebViewDialog : Form
    {
        public string ResponseUri { get; private set; }
        public WebViewDialog(string url)
        {
            InitializeComponent();
            webBrowser.Navigate(new Uri(url));
        }

        private void WebViewDialog_Load(object sender, EventArgs e)
        {
            // Optionally, you can handle navigation events here
        }

        private void webBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            ResponseUri = e.Url.ToString();
            DialogResult = DialogResult.OK;
        }

        private void webBrowser_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        { // Optionally, you can handle navigation events here

        }
        public static async Task<string> Show(string url)
        {
            var tcs = new TaskCompletionSource<string>();

            var webViewDialog = new WebViewDialog(url);
            webViewDialog.FormClosed += (sender, args) =>
            {
                if (webViewDialog.DialogResult == DialogResult.OK)
                {
                    tcs.TrySetResult(webViewDialog.ResponseUri);
                }
                else
                {
                    tcs.TrySetException(new Exception("Authorization canceled by the user."));
                }
            };

            webViewDialog.ShowDialog();
            return await tcs.Task;
        }
    }
}
