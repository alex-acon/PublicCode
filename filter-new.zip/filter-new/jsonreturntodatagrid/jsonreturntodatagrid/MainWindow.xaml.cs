﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using jsonreturntodatagrid;
using System.Windows.Controls;
using System.Windows.Data;
using Newtonsoft.Json;
using System.Windows.Input;

namespace jsonreturntodatagrid
{
    public partial class MainWindow : Window
    {
        //public class SampleData
        //{
        //    public int AppID { get; set; }
        //    public string ObjectType { get; set; }
        //    public string ObjectName { get; set; }
        //}
        private readonly string clientId = ConfigurationManager.AppSettings["ClientId"];
        private readonly string stsEndpoint = ConfigurationManager.AppSettings["StsEndpoint"];
        private readonly string apiEndpoint = ConfigurationManager.AppSettings["ApiEndpoint"];
        private readonly string resource = ConfigurationManager.AppSettings["Resource"];
        private readonly string redirectUri = ConfigurationManager.AppSettings["RedirectUri"];

        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
        private ICollectionView dataView;
       // public ObservableCollection<SampleData> SampleDataCollection { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
            dataView = CollectionViewSource.GetDefaultView(originalData);
            DataGrid.ItemsSource = dataView;

            //SampleDataCollection = new ObservableCollection<SampleData>();
            //DataGrid.ItemsSource = SampleDataCollection;

            //// Add sample data for testing
            //SampleDataCollection.Add(new SampleData { AppID = 123456, ObjectType = "farms", ObjectName = "server1" });
            //SampleDataCollection.Add(new SampleData { AppID = 789012, ObjectType = "factories", ObjectName = "machineA" });
            //SampleDataCollection.Add(new SampleData { AppID = 345678, ObjectType = "warehouses", ObjectName = "storage1" });
            
        }

        private async void RetrieveData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Loading data...(This may take a while to fetch the data so please be patient and wait)", "Loading", MessageBoxButton.OK, MessageBoxImage.Information);
                Mouse.OverrideCursor = Cursors.Wait;
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
                Mouse.OverrideCursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
            DataGrid.ItemsSource = null;
        }

        private async Task PerformOAuthFlow()
        {
            await ShowAuthorizationDialog();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }
        private Dictionary<string, string> ParseQueryString(string uri)
        {
            var query = new Uri(uri).Query;
            var queryParams = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(query))
            {
                var pairs = query.TrimStart('?').Split('&');
                foreach (var pair in pairs)
                {
                    var keyValue = pair.Split('=');
                    if (keyValue.Length == 2)
                    {
                        queryParams[keyValue[0]] = Uri.UnescapeDataString(keyValue[1]);
                    }
                }
            }

            return queryParams;
        }

        private async Task ShowAuthorizationDialog()
        {
            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";
            var responseUri = await WebViewDialog.Show(authorizationUri);
            var queryParams = ParseQueryString(responseUri);
            authorizationCode = queryParams["code"];
        }

        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri),
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {
            
            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = JsonConvert.DeserializeObject<dynamic[]>(jsonData);
            DataGrid.ItemsSource = data;
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }

    }
}
