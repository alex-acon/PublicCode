﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Newtonsoft.Json;

namespace jsonreturntodatagrid
{
    public partial class MainWindow : Window
    {
        private readonly string clientId = ConfigurationManager.AppSettings["ClientId"];
        private readonly string stsEndpoint = ConfigurationManager.AppSettings["StsEndpoint"];
        private readonly string apiEndpoint = ConfigurationManager.AppSettings["ApiEndpoint"];
        private readonly string resource = ConfigurationManager.AppSettings["Resource"];
        private readonly string redirectUri = ConfigurationManager.AppSettings["RedirectUri"]; // Add RedirectUri to your app.config

        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
        private ICollectionView dataView;

        public MainWindow()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
            dataView = CollectionViewSource.GetDefaultView(originalData);
            DataGrid.ItemsSource = dataView;
        }

        private async void RetrieveData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
            DataGrid.ItemsSource = null;
        }

        private async Task PerformOAuthFlow()
        {
            authorizationCode = await GetAuthorizationCode();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }

        private async Task<string> GetAuthorizationCode()
        {
            MessageBox.Show("Please perform user login to obtain the authorization code.");

            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";

            var responseUri = await ShowAuthorizationDialog(authorizationUri);

            var queryParams = ParseQueryString(responseUri);
            return queryParams["code"];
        }

        private IDictionary<string, string> ParseQueryString(string uri)
        {
            var queryString = new Uri(uri).Query.TrimStart('?');
            return queryString.Split('&')
                              .Select(parameter => parameter.Split('='))
                              .ToDictionary(pair => Uri.UnescapeDataString(pair[0]),
                                            pair => Uri.UnescapeDataString(pair[1]));
        }

        private async Task<string> ShowAuthorizationDialog(string authorizationUri)
        {
            var webViewDialog = new WebViewDialog(authorizationUri); // Replace WebViewDialog with your actual UI component

            if (webViewDialog.ShowDialog() == true)
            {
                return webViewDialog.ResponseUri; // Assuming ResponseUri is a property in your WebViewDialog
            }
            else
            {
                throw new Exception("Authorization canceled by the user.");
            }
        }


        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri), // Include the redirect_uri in the token exchange
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {
            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = JsonConvert.DeserializeObject<dynamic[]>(jsonData);
            DataGrid.ItemsSource = data;
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }
    }
}
