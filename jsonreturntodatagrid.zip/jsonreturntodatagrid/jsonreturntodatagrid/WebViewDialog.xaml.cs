﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace jsonreturntodatagrid
{
    /// <summary>
    /// Interaction logic for WebViewDialog.xaml
    /// </summary>
    public partial class WebViewDialog : Window
    {
        public string ResponseUri { get; private set; }
        public WebViewDialog(string url)
        {
            InitializeComponent(); webBrowser.Navigate(new Uri(url));
        }
        private void WebBrowser_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            ResponseUri = e.Uri.ToString();
            DialogResult = true;
        }

        private void WebBrowser_Navigating(object sender, System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            // Optionally, you can handle navigation events here
        }
    }
}
