﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using jsonreturntodatagrid;
using System.Windows.Controls;
using System.Windows.Data;
using Newtonsoft.Json;
using System.Windows.Input;
using OfficeOpenXml;
using System.Linq;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
namespace jsonreturntodatagrid
{
    public partial class MainWindow : Window
    {
        public class SampleData
        {
            public int AppID { get; set; }
            public string ObjectType { get; set; }
            public string ObjectName { get; set; }
        }
        private  string clientId ;
        private  string stsEndpoint;
        private  string apiEndpoint;
        private  string resource;
        private string redirectUri;
        private string authorizationCode;
        private string accessToken;
        private ObservableCollection<dynamic> originalData;
        private ICollectionView dataView;
        
        public MainWindow()
        {
            InitializeComponent();
            originalData = new ObservableCollection<dynamic>();
            dataView = CollectionViewSource.GetDefaultView(originalData);
            DataGrid.ItemsSource = dataView;

            //originalData = new ObservableCollection<dynamic>();
            //DataGrid.ItemsSource = originalData;

            //// Add sample data for testing

            //originalData.Add(new SampleData { AppID = 123456, ObjectType = "farms", ObjectName = "server1" });
            //originalData.Add(new SampleData { AppID = 789012, ObjectType = "factories", ObjectName = "machineA" });
            //originalData.Add(new SampleData { AppID = 345678, ObjectType = "warehouses", ObjectName = "storage1" });

        }

        private async void RetrieveData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Loading data...(This may take a while to fetch the data so please be patient and wait)", "Loading", MessageBoxButton.OK, MessageBoxImage.Information);
                Mouse.OverrideCursor = Cursors.Wait;
                await PerformOAuthFlow();
                var requestData = await GetData();
                DisplayData(requestData);
                Mouse.OverrideCursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            AppIDTextBox.Clear();
            ObjectTypeTextBox.Clear();
            ObjectNameTextBox.Clear();
            DataGrid.ItemsSource = null;
        }

        private async Task PerformOAuthFlow()
        {
            await ShowAuthorizationDialog();
            accessToken = await ExchangeAuthorizationCodeForToken(authorizationCode);
        }
        private Dictionary<string, string> ParseQueryString(string uri)
        {
            var query = new Uri(uri).Query;
            var queryParams = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(query))
            {
                var pairs = query.TrimStart('?').Split('&');
                foreach (var pair in pairs)
                {
                    var keyValue = pair.Split('=');
                    if (keyValue.Length == 2)
                    {
                        queryParams[keyValue[0]] = Uri.UnescapeDataString(keyValue[1]);
                    }
                }
            }

            return queryParams;
        }

        private async Task ShowAuthorizationDialog()
        {
            var authorizationUri = $"{stsEndpoint}?client_id={clientId}&response_type=code&redirect_uri={Uri.EscapeUriString(redirectUri)}&resource={resource}";
            var responseUri = await WebViewDialog.Show(authorizationUri);
            var queryParams = ParseQueryString(responseUri);
            authorizationCode = queryParams["code"];
        }

        private async Task<string> ExchangeAuthorizationCodeForToken(string authorizationCode)
        {
            using (var client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "authorization_code"),
                    new KeyValuePair<string, string>("code", authorizationCode),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("redirect_uri", redirectUri),
                    new KeyValuePair<string, string>("resource", resource)
                });

                var response = await client.PostAsync(stsEndpoint, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }

                throw new Exception($"Failed to retrieve access token. Response: {responseContent}");
            }
        }

        private async Task<string> GetData()
        {

            var apiUrl = $"{apiEndpoint}?AppID={AppIDTextBox.Text}&ObjectType={ObjectTypeTextBox.Text}";

            if (!string.IsNullOrEmpty(ObjectNameTextBox.Text))
            {
                apiUrl += $"&ObjectName={ObjectNameTextBox.Text}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                var response = await client.GetAsync(apiUrl);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return responseContent;
                }

                throw new Exception($"Failed to retrieve data. Response: {responseContent}");
            }
        }

        private void DisplayData(string jsonData)
        {
            var data = JsonConvert.DeserializeObject<dynamic[]>(jsonData);
            DataGrid.ItemsSource = data;
        }

        private void LogError(string errorMessage)
        {
            Console.WriteLine($"[{DateTime.Now}] Error: {errorMessage}");
        }
        //private void ExportToExcel(string filePath)
        //{
        //    // Create a new Excel package
        //    using (ExcelPackage excelPackage = new ExcelPackage())
        //    {
        //        // Add a new worksheet to the Excel package
        //        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Data");

        //        // Get the data from the DataGrid
        //        var data = (IEnumerable<dynamic>)DataGrid.ItemsSource;

        //        // Write the column headers to the first row of the worksheet
        //        int columnCount = 1;
        //        foreach (var property in data.First().GetType().GetProperties())
        //        {
        //            worksheet.Cells[1, columnCount].Value = property.Name;
        //            columnCount++;
        //        }

        //        // Write the data to the worksheet
        //        int rowCount = 2;
        //        foreach (var item in data)
        //        {
        //            columnCount = 1;
        //            foreach (var property in item.GetType().GetProperties())
        //            {
        //                worksheet.Cells[rowCount, columnCount].Value = property.GetValue(item);
        //                columnCount++;
        //            }
        //            rowCount++;
        //        }

        //        // Save the Excel package to the specified file path
        //        File.WriteAllBytes(filePath, excelPackage.GetAsByteArray());
        //    }

        //    MessageBox.Show("Data exported to Excel successfully.", "Export to Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        //}


        private void ExportToExcel(string filePath)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Add();
            Excel.Worksheet worksheet = workbook.Worksheets[1];

            try
            {
                // Get the data from the DataGrid
                var data = (IEnumerable<dynamic>)DataGrid.ItemsSource;

                // Write the column headers to the Excel worksheet
                int columnCount = 1;
                foreach (var property in data.First().GetType().GetProperties())
                {
                    worksheet.Cells[1, columnCount] = property.Name;
                    columnCount++;
                }

                // Write the data to the Excel worksheet
                int rowCount = 2;
                foreach (var item in data)
                {
                    columnCount = 1;
                    foreach (var property in item.GetType().GetProperties())
                    {
                        worksheet.Cells[rowCount, columnCount] = property.GetValue(item);
                        columnCount++;
                    }
                    rowCount++;
                }

                // Save the Excel workbook
                workbook.SaveAs(filePath);
                excelApp.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error exporting to Excel: {ex.Message}", "Export to Excel Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                workbook.Close();
                excelApp.Quit();

                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                ReleaseObject(excelApp);
            }
        }

        // Helper method to release COM objects
        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show($"Exception occurred while releasing object: {ex.Message}", "Release COM Object Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                GC.Collect();
            }
        }
        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            
            // Save the Excel file
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            saveFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
            if (saveFileDialog.ShowDialog() == true)
            {
                ExportToExcel(saveFileDialog.FileName);
               // excelPackage.SaveAs(new System.IO.FileInfo(saveFileDialog.FileName));
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if (radioButton != null && radioButton.IsChecked == true)
            {
                if (radioButton.Name == "ProdRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["ProdClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["ProdStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["ProdApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["ProdResource"];
                    redirectUri = ConfigurationManager.AppSettings["ProdRedirectUri"];
                }
                else if (radioButton.Name == "DevRadioButton")
                {
                    clientId = ConfigurationManager.AppSettings["DevClientId"];
                    stsEndpoint = ConfigurationManager.AppSettings["DevStsEndpoint"];
                    apiEndpoint = ConfigurationManager.AppSettings["DevApiEndpoint"];
                    resource = ConfigurationManager.AppSettings["DevResource"];
                    redirectUri = ConfigurationManager.AppSettings["DevRedirectUri"];
                }
            }
        }
        private void SearchData(string searchText)
        {
            if (DataGrid.ItemsSource == null)
            {
                return;
            }

            ICollectionView dataView = CollectionViewSource.GetDefaultView(DataGrid.ItemsSource);
            if (string.IsNullOrWhiteSpace(searchText))
            {
                dataView.Filter = null;
            }
            else
            {
                dataView.Filter = item =>
                {
                    SampleData data = item as SampleData;
                    if (data != null)
                    {
                        return data.AppID.ToString().Contains(searchText)
                            || data.ObjectType.Contains(searchText)
                            || data.ObjectName.Contains(searchText);
                    }
                    return false;
                };
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = SearchTextBox.Text;
            SearchData(searchText);
        }

        //private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (!string.IsNullOrEmpty(SearchTextBox.Text))
        //    {
        //        var filteredData = originalData.Where(item => item.AppID.ToString().Contains(SearchTextBox.Text)
        //                                                            || item.ObjectType.Contains(SearchTextBox.Text)
        //                                                            || item.ObjectName.Contains(SearchTextBox.Text)).ToList();
        //        DataGrid.ItemsSource = filteredData;
        //    }
        //    else
        //    {
        //        DataGrid.ItemsSource = originalData;
        //    }
        //}
    }
}